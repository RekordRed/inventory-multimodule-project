package com.callmextrm.notification_microservice.entity;

public enum Type {
    ORDER_CREATED
}
