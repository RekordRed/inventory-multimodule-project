package com.callmextrm.order_microservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderMicroserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
