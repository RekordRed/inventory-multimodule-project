package com.callmextrm.order_microservice.exception;

public class Quantity extends RuntimeException {
    public Quantity(String message) {
        super(message);
    }


}
