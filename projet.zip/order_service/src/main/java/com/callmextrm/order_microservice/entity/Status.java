package com.callmextrm.order_microservice.entity;

public enum Status {
    CREATED,
    CONFIRMED,
    REJECTED
}
