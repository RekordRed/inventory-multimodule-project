package com.callmextrm.product_service.product;

public enum Status {
    Active,
    Discontinued
}
