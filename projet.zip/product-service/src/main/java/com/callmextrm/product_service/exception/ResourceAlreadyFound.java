package com.callmextrm.product_service.exception;

public class ResourceAlreadyFound extends RuntimeException {
    public ResourceAlreadyFound(String message) {
        super(message);
    }

}
