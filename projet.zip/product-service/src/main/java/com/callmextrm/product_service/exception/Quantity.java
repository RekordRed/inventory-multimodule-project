package com.callmextrm.product_service.exception;

public class Quantity extends RuntimeException {
    public Quantity(String message) {
        super(message);
    }


}
